from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.exceptions import ValidationError
from decimal import Decimal
from datetime import timedelta

class Investor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # Additional investor details
    created_at = models.DateTimeField(auto_now_add=True)
    is_waiting = models.BooleanField(default=False)  # Track if the investor is waiting
    waiting_since = models.DateTimeField(null=True, blank=True)  # Track when they started waiting
    waiting_investment_id = models.IntegerField(null=True, blank=True)  # Track which investment is waiting
    phone_number = models.CharField(max_length=20, null=True, blank=True)  # Contact information for pairing

    def __str__(self):
        return self.user.username

class Investment(models.Model):
    investor = models.ForeignKey(Investor, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    remaining_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    confirmation_date = models.DateTimeField(null=True, blank=True)  # When the paired user confirms payment
    maturation_date = models.DateTimeField(null=True, blank=True)  # Will be set after confirmation
    is_matured = models.BooleanField(default=False)
    paired = models.BooleanField(default=False)
    daily_interest_rate = Decimal('0.03')  # 3% daily interest rate

    def save(self, *args, **kwargs):
        # Ensure remaining_amount is set to the initial amount when an investment is created
        if not self.pk:
            self.remaining_amount = self.amount
        
        # Check if the investment has matured
        if self.confirmation_date and self.maturation_date and self.maturation_date <= timezone.now() and not self.is_matured:
            self.is_matured = True
        
        super().save(*args, **kwargs)
        
        # If this investment just matured, trigger pairing
        if self.is_matured and self.remaining_amount > 0:
            from .tasks import match_waiting_investors
            match_waiting_investors.delay()

    def clean(self):
        if self.maturation_date and self.maturation_date <= timezone.now():
            raise ValidationError("Maturation date must be in the future.")
    
    def calculate_daily_interest(self):
        """Calculate the daily interest (3%) for this investment"""
        return self.amount * self.daily_interest_rate
    
    def calculate_total_interest(self):
        """Calculate the total interest earned so far"""
        if not self.confirmation_date:
            return Decimal('0.00')
            
        if self.is_matured:
            # If matured, calculate interest for the entire period
            days = (self.maturation_date - self.confirmation_date).days
        else:
            # If not matured, calculate interest up to now
            days = (timezone.now() - self.confirmation_date).days
        
        daily_interest = self.calculate_daily_interest()
        return daily_interest * days
    
    def calculate_projected_interest(self):
        """Calculate the projected interest at maturation"""
        if not self.confirmation_date or not self.maturation_date:
            return Decimal('0.00')
            
        total_days = (self.maturation_date - self.confirmation_date).days
        daily_interest = self.calculate_daily_interest()
        return daily_interest * total_days
    
    def calculate_end_return(self):
        """Calculate the total amount to be returned at maturation (principal + interest)"""
        total_interest = self.calculate_projected_interest()
        return self.amount + total_interest
        
    def __str__(self):
        return f"Investment {self.id} by {self.investor.user.username}"

class Pairing(models.Model):
    investor = models.ForeignKey(Investor, related_name='new_investor', on_delete=models.CASCADE)
    paired_investment = models.ForeignKey(Investment, on_delete=models.CASCADE)
    paired_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    confirmed = models.BooleanField(default=False)
    confirmation_date = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    paired_to = models.ForeignKey(Investor, related_name='paired_to_investor', on_delete=models.CASCADE, null=True, blank=True)

    def save(self, *args, **kwargs):
        # Set the paired_to field to the investor who owns the paired_investment
        if self.paired_investment and not self.paired_to:
            self.paired_to = self.paired_investment.investor
            
        # If this is a new confirmation
        if self.confirmed and not self.confirmation_date:
            self.confirmation_date = timezone.now()
            # Set the confirmation date on the paired investment
            self.paired_investment.confirmation_date = self.confirmation_date
            # Set the maturation date (30 days from confirmation)
            self.paired_investment.maturation_date = self.confirmation_date + timedelta(days=30)
            self.paired_investment.save()
            
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.investor.user.username} paired with {self.paired_to.user.username if self.paired_to else self.paired_investment.investor.user.username} for {self.paired_amount}"
