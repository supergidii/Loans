from celery import shared_task
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
from .models import Investor, Investment, Pairing
from django.db.models import Q

@shared_task
def match_waiting_investors():
    """
    Match matured investments with waiting investors.
    A matured investment can be paired with an immature investment from another user.
    """
    # Get all matured investments that haven't been fully paired
    matured_investments = Investment.objects.filter(
        is_matured=True,
        remaining_amount__gt=0
    ).select_related('investor')

    for matured_inv in matured_investments:
        # Find immature investments from other users
        immature_investments = Investment.objects.filter(
            is_matured=False,
            remaining_amount__gt=0
        ).exclude(
            investor=matured_inv.investor  # Exclude investments from the same user
        ).select_related('investor')

        for immature_inv in immature_investments:
            # Calculate how much can be paired
            pairing_amount = min(matured_inv.remaining_amount, immature_inv.remaining_amount)
            
            if pairing_amount > 0:
                # Create the pairing
                pairing = Pairing.objects.create(
                    investor=immature_inv.investor,
                    paired_investment=matured_inv,
                    paired_amount=pairing_amount,
                    paired_to=matured_inv.investor  # Set the paired_to field to the matured investment's investor
                )

                # Update remaining amounts
                matured_inv.remaining_amount -= pairing_amount
                immature_inv.remaining_amount -= pairing_amount

                # Update paired status if fully paired
                if matured_inv.remaining_amount == 0:
                    matured_inv.paired = True
                if immature_inv.remaining_amount == 0:
                    immature_inv.paired = True
                    # Update investor's waiting status
                    immature_inv.investor.is_waiting = False
                    immature_inv.investor.waiting_since = None
                    immature_inv.investor.waiting_investment_id = None
                    immature_inv.investor.save()

                # Save the changes
                matured_inv.save()
                immature_inv.save()

                # If the matured investment is fully paired, break the loop
                if matured_inv.remaining_amount == 0:
                    break

def notify_user_of_pairing(investor, paired_investment, amount):
    subject = 'Investment Paired'
    message = f'Dear {investor.user.username},\n\nYour investment has been paired with {paired_investment.investor.user.username} for an amount of ${amount}.\n\nBest regards,\nLoan Management System'
    
    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [investor.user.email],
            fail_silently=False,
        )
    except Exception as e:
        print(f"Failed to send email to {investor.user.email}: {str(e)}") 