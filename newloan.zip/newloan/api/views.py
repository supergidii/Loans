from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from decimal import Decimal
from django.db.models import Sum, F, Q, Count

from .forms import InvestorProfileForm
from .models import Investor, Investment, Pairing
from .tasks import match_waiting_investors

# Create your views here.

@login_required
def create_investment(request):
    if request.method == 'POST':
        amount = request.POST['amount']
        maturation_date = request.POST['maturation_date']
        investor = request.user.investor
        
        investment = Investment.objects.create(
            investor=investor, 
            amount=amount, 
            maturation_date=maturation_date
        )
        return redirect('api:investment_detail', investment_id=investment.id)
    
    return render(request, 'create_investment.html')

@login_required
def match_investor(request):
    new_investor = request.user.investor
    matured_investments = Investment.objects.filter(is_matured=True, remaining_amount__gt=0).order_by('created_at')

    if matured_investments.exists():
        # Get the new investment that needs pairing
        new_investment = Investment.objects.filter(
            investor=new_investor,
            remaining_amount__gt=0
        ).first()

        if new_investment:
            for matured_investment in matured_investments:
                if new_investment.remaining_amount <= 0:
                    break  # If new investment is fully paired, exit the loop

                # Calculate the return amount for the matured investment
                return_amount = matured_investment.calculate_end_return()
                
                # Determine the amount to pair - use the return amount
                amount_to_pair = min(new_investment.remaining_amount, return_amount)

                # Create the pairing
                Pairing.objects.create(
                    investor=new_investor,
                    paired_investment=matured_investment,
                    paired_amount=amount_to_pair
                )

                # Update remaining amounts
                new_investment.remaining_amount -= amount_to_pair
                matured_investment.remaining_amount = 0  # Set to 0 since we're using the full return amount

                # Update paired status if fully paired
                if matured_investment.remaining_amount == 0:
                    matured_investment.paired = True
                
                # Save the changes
                new_investment.save()
                matured_investment.save()

                messages.success(request, f"Your investment has been paired with {matured_investment.investor.user.username} for ${amount_to_pair}")

            # If the investment still has remaining amount, add to waiting queue
            if new_investment.remaining_amount > 0:
                new_investor.is_waiting = True
                new_investor.waiting_since = timezone.now()
                new_investor.save()
                messages.info(request, f"Your remaining investment of ${new_investment.remaining_amount} has been added to the waiting queue.")
            
            return redirect('api:investment_status')
    
    # If no matured investments are available or no new investment to pair
    new_investor.is_waiting = True
    new_investor.waiting_since = timezone.now()
    new_investor.save()
    messages.info(request, "You have been added to the waiting queue. You will be paired when investments mature.")
    return render(request, 'waiting_for_pairing.html', {
        'investor': new_investor
    })

@login_required
def investment_detail(request, investment_id):
    investment = get_object_or_404(Investment, id=investment_id, investor=request.user.investor)
    return render(request, 'investment_detail.html', {'investment': investment})

@login_required
def pairing_detail(request, pairing_id):
    pairing = get_object_or_404(Pairing, id=pairing_id)
    return render(request, 'pairing_detail.html', {'pairing': pairing})

@login_required
def investment_status(request, investment_id=None):
    # Get the investment
    if investment_id:
        investment = get_object_or_404(Investment, id=investment_id, investor=request.user.investor)
    else:
        # Get the most recent investment for the current user
        investment = Investment.objects.filter(
            investor=request.user.investor,
        ).order_by('-created_at').first()

    # Check if the investment has matured
    if investment and investment.maturation_date <= timezone.now() and not investment.is_matured:
        investment.is_matured = True
        investment.save()  # This will trigger the pairing process

    # Get all pairings for this investment
    pairings = None
    if investment:
        pairings = Pairing.objects.filter(
            investor=request.user.investor,
            paired_investment__created_at__lte=investment.created_at
        ).order_by('-created_at')

    return render(request, 'investment_status.html', {
        'investment': investment,
        'pairings': pairings,
    })

@login_required
def dashboard(request):
    investor = request.user.investor
    investments = Investment.objects.filter(investor=investor).order_by('-created_at')

    # Calculate returns for each investment
    total_returns = sum(inv.calculate_end_return() for inv in investments)
    total_interest = sum(inv.calculate_projected_interest() for inv in investments)
    projected_returns = sum(inv.calculate_end_return() for inv in investments if not inv.is_matured)

    # Calculate waiting amount as cumulative total returns
    waiting_returns = sum(
        inv.calculate_end_return() 
        for inv in investments 
        if inv.remaining_amount > 0
    )

    # Calculate statistics
    stats = investments.aggregate(
        total_invested=Sum('amount'),
        total_paired=Sum('amount') - Sum('remaining_amount'),
        active_investments=Count('id')
    )

    # Check if there are matured investments available for pairing
    matured_investments_available = Investment.objects.filter(
        is_matured=True, 
        remaining_amount__gt=0
    ).exclude(
        investor=investor
    ).exists()

    # Get active pairings for the user
    active_pairings = Pairing.objects.filter(
        investor=investor
    ).select_related(
        'paired_investment', 
        'paired_investment__investor', 
        'paired_investment__investor__user'
    ).order_by('-created_at')

    # Get the investment the user is waiting with (if any)
    waiting_investment = None
    if investor.is_waiting and hasattr(investor, 'waiting_investment_id'):
        waiting_investment = Investment.objects.filter(id=investor.waiting_investment_id).first()

    context = {
        'investments': investments,
        'total_invested': stats['total_invested'] or Decimal('0.00'),
        'total_paired': stats['total_paired'] or Decimal('0.00'),
        'total_waiting': waiting_returns,  # Using cumulative returns instead of remaining amount
        'active_investments': stats['active_investments'] or 0,
        'total_returns': total_returns,
        'total_interest': total_interest,
        'projected_returns': projected_returns,
        'matured_investments_available': matured_investments_available,
        'active_pairings': active_pairings,
        'waiting_investment': waiting_investment
    }

    return render(request, 'dashboard.html', context)

@login_required
def update_profile(request):
    investor = request.user.investor
    
    if request.method == 'POST':
        form = InvestorProfileForm(request.POST, instance=investor)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated successfully.')
            return redirect('frontend:dashboard')
    else:
        form = InvestorProfileForm(instance=investor)
    
    return render(request, 'update_profile.html', {'form': form}) 
@login_required
def cancel_waiting(request):
    if request.method == 'POST':
        investor = request.user.investor
        investment_id = request.POST.get('investment_id')

        if investment_id:
            investment = get_object_or_404(Investment, id=investment_id, investor=investor)
            
            # Only cancel if the investment has remaining amount and investor is waiting
            if investment.remaining_amount > 0 and investor.is_waiting:
                investor.is_waiting = False
                investor.save()
                messages.success(request, "Your waiting status has been cancelled.")
            else:
                messages.error(request, "Unable to cancel waiting status.")
        
        return redirect('api:dashboard')
    
    return redirect('api:dashboard')

@login_required
def confirm_payment(request, pairing_id):
    pairing = get_object_or_404(Pairing, id=pairing_id)

    # Check if the user confirming is the owner of the paired matured investment
    if request.user != pairing.paired_investment.investor.user:
        messages.error(request, "You are not authorized to confirm this payment.")
        return redirect('api:investment_status')

    # Confirm the payment and start the countdown for the new investor's investment
    pairing.confirmed = True
    pairing.paired_investment.is_matured = False  # Mark as paid
    pairing.save()

    # Start countdown for the new investor's investment (by setting a maturation date)
    new_investment = Investment.objects.filter(
        investor=pairing.investor,
        remaining_amount__gt=0
    ).first()
    
    if new_investment:
        # Set the maturation date based on your business logic (e.g., 30 days)
        new_investment.maturation_date = timezone.now() + timezone.timedelta(days=30)
        new_investment.save()
        
        # Notify the new investor
        messages.success(
            request, 
            f"Payment confirmed. The new investor's countdown has started and will mature in 30 days."
        )
    else:
        messages.warning(request, "Payment confirmed but no active investment found for the new investor.")

    return redirect('api:investment_status')

# Authentication views
def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Create an investor profile for the new user
            Investor.objects.create(user=user)
            # Log the user in
            login(request, user)
            messages.success(request, "Registration successful! Welcome to the Investment Platform.")
            return redirect('api:dashboard')
        else:
            messages.error(request, "Registration failed. Please correct the errors below.")
    else:
        form = UserCreationForm()
    
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                return redirect('api:dashboard')
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, 'login.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out successfully.")
    return redirect('api:login')
