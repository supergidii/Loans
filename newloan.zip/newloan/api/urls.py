from django.urls import path
from . import views

app_name = 'api'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('create-investment/', views.create_investment, name='create_investment'),
    path('match-investor/', views.match_investor, name='match_investor'),
    path('investment/<int:investment_id>/', views.investment_detail, name='investment_detail'),
    path('pairing/<int:pairing_id>/', views.pairing_detail, name='pairing_detail'),
    path('investment-status/', views.investment_status, name='investment_status'),
    path('investment-status/<int:investment_id>/', views.investment_status, name='investment_status_by_id'),
    path('cancel-waiting/', views.cancel_waiting, name='cancel_waiting'),
    path('confirm-payment/<int:pairing_id>/', views.confirm_payment, name='confirm_payment'),
    
    # Authentication URLs
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/update/', views.update_profile, name='update_profile'),
] 